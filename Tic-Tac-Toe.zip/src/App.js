import React from 'react';
import './App.css';
import Board from './Game/TicTacToe';

function App() {
  return (
    <div className="App">
      {/* <Main/> */}
      {/* <ToDoList /> */}
      <Board/>

    </div>
  );
}

export default App;
